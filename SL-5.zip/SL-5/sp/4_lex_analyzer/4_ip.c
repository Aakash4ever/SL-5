#include<stdio.h>
int main()
{ 
    char a[25];
    printf("\n\tenter ur name:\t\n");
    gets(a);
    puts(a);    
    return 0;
}
