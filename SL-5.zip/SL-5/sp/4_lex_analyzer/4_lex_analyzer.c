/*
	Name :- Aakash Bhaskar Kalore,
	Branch:- IT, Std. :- TE, Div. :- A,
	Roll no. :- 35026,
	Sub. :-  SP,
*/

#include<stdio.h>
#include<string.h>
#include<ctype.h>

struct symtable
{
	int sym_cnt;
	char sym_name[10];
}st[10];

struct littable
{
	int lit_cnt;
	char lit_name[10];
}lt[10];

int ist=0,ilt=0;

void dispst(struct symtable *st)
{
	printf("\n\t\t%d\t %s\t",st->sym_cnt,st->sym_name);
}

void displt(struct littable *lt)
{
	printf("\n\t\t%d\t %s\t",lt->lit_cnt,lt->lit_name);
}

void add_st(int cnt,char name[10])
{
	st[ist].sym_cnt=cnt;
	strcpy(st[ist].sym_name,name);
	ist++;
}

void add_lt(int cnt,char name[10])
{
	lt[ilt].lit_cnt=cnt;
	strcpy(lt[ilt].lit_name,name);
	ilt++;
}

void main()
{
	FILE *ip,*fo,*fop,*fk;
 	int flag=0,i=1;
 	char c,t,a[15],ch[15],file[20];
 	
 	printf("\n\n\t\t**Lexical Analyzer**\n");
 	
 	printf("\n\n\tEnter the input file name : ");
 	scanf("%s",file);
 
 	ip=fopen(file,"r");
 	fo=fopen("inter.c","w");
 	fop=fopen("4_ip_oper.c","r");
 	fk=fopen("4_ip_key.c","r");
 	
 	c=getc(ip);
 	
 	while(!feof(ip))
 	{
  		if( isalpha(c) || isdigit(c) || (c=='['||c==']' || c=='.'==1) )
   			fputc(c,fo);
  		else
  		{
  			if(c=='\n')
  				fprintf(fo,"\t$\t");
  			else
  				fprintf(fo,"\t%c\t",c);
  		}
  		c=getc(ip);
 	}
 	fclose(ip);
 	fclose(fo);
 	
 	printf("\n\n\tUniversal Table: \n\t");
	printf("\n\t\tToken_Cnt  Token_Name");
 	
 	ip=fopen("inter.c","r");
 	
 	fscanf(ip,"%s",a);
 	while(!feof(ip))
 	{
 		if((strcmp(a,"$")==0))
 		{
  			fscanf(ip,"%s",a);
 		}
 		fscanf(fop,"%s",ch);
 		while(!feof(fop))
 		{
  			if(strcmp(ch,a)==0)
  			{
  				fscanf(fop,"%s",ch);
  				printf("\n\t\t%s\t   %s",a,ch);
  				flag=1;
  			}
  			fscanf(fop,"%s",ch);
 		}
 		rewind(fop);
 		fscanf(fk,"%s",ch);
 		while(!feof(fk))
 		{
  			if(strcmp(ch,a)==0)
  			{
  				fscanf(fk,"%s",ch);
  				printf("\n\t\t%s\t   keyword",a);
  				flag=1;
  			}
 			fscanf(fk,"%s",ch);
 		}
 		rewind(fk);
 		if(flag==0)
 		{
 			if(isdigit(a[0]))
 			{
  				printf("\n\t\t%s\t   Literal / Constant",a);
  				add_lt(ilt+1,a);
			}
 			else
 			{
 		 		printf("\n\t\t%s\t   Symbol",a);
 		 		add_st(ist+1,a);
			}
 		}
 		flag=0;
 		fscanf(ip,"%s",a);
 	}
 	
 	printf("\n\n\tSymbol Table: \n\t");
	printf("\n\t\tSym_Cnt  Sym_Name");	
	for(i=0;i<ist;i++)
		dispst(&st[i]);
	
	printf("\n\n\tLiteral Table: \n\t");
	printf("\n\t\tLit_Cnt  Lit_Name");		
	for(i=0;i<ilt;i++)
		displt(&lt[i]);
		
	printf("\n\n");
}
