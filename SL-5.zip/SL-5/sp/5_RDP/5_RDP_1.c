/*
	Name :- Aakash Bhaskar Kalore,
	Branch:- IT, Std. :- TE, Div. :- A,
	Roll no. :- 35026,
	Sub. :-  SP,



	Q.
		E-> E+T | E-T | T
		T-> T*F | T | F
		F-> (E) | id
		
	Ans.
		E-> TE'
		E'-> +TE' | -TE' | epsilon
		T-> FT'
		T'-> *FT' | /FT' | epsilon
		F-> (E) | id 
*/

#include<stdio.h>

void E();
void Edash();
void T();
void Tdash();
void F();

char expr[20]={'\0'};
int ptr=0,ERROR=0;
          
int main()
{
	
	printf("\n\tEnter the Expression : ");
	scanf("%s",expr);
    
    E();
    
    if(ERROR==0 && expr[ptr]=='\0')
    	printf("\n\tValid \n");
    else
    	printf("\n\tInValid \n");
	return 0;
}
 
void E()
{
	T();
	Edash();
}

void Edash()
{
	if(expr[ptr]=='+' || expr[ptr]=='-')
    {
    	ptr++;
    	T();
    	Edash();
    }
    else if(expr[ptr]=='\0' || expr[ptr]==')');
    	//do nothing
    else
    	ERROR=1;
}

void T()
{
    F();
    Tdash();
}

void Tdash()
{
    if(expr[ptr]=='*' || expr[ptr]=='/')
    {
		ptr++;
		F();
		Tdash();
	}
    else if(expr[ptr]=='\0' || expr[ptr]=='+' || expr[ptr]=='-' || expr[ptr]==')');
    	//do nothing
	else
		ERROR=1;
}

void F()
{
	if( expr[ptr]=='i' && expr[ptr+1]=='d' )
		ptr+=2;
	else if(expr[ptr]=='(')
	{
		ptr++;
		E();
		if(expr[ptr]==')')
			ptr++;
		else
			ERROR=1;
	}
	else
		ERROR=1;
}




