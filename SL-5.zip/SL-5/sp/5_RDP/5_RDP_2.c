/*
	Name :- Aakash Bhaskar Kalore,
	Branch:- IT, Std. :- TE, Div. :- A,
	Roll no. :- 35026,
	Sub. :-  SP,



	Q.
		S -> a | + | (T)
		T -> S U
		U -> , S U | epsilon
*/

#include<stdio.h>

void S();
void T();
void U();

char expr[20]={'\0'};
int ptr=0,ERROR=0;

int main()
{
	
	printf("\n\tEnter the Expression : ");
	scanf("%s",expr);
	
	S();
	
	if(ERROR==0 && expr[ptr]=='\0')
		printf("\n\tValid \n");
	else
		printf("\n\tInValid \n");
	return 0;
}

void S()
{
	if(expr[ptr]=='a' || expr[ptr]=='+')
		ptr++;
	else if(expr[ptr]=='(')
	{
		ptr++;
		T();
		if(expr[ptr]==')')
			ptr++;
		else
			ERROR=1;
	}
	else
		ERROR=1;
}

void T()
{
	S();
	U();
}

void U()
{
	if(expr[ptr]==',')
	{
		ptr++;
		S();
		U();
	}
	else if(expr[ptr]==')');
		//do nothing
	else
		ERROR=1;
}



