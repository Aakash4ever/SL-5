/*
	Name :- Aakash Bhaskar Kalore,
	Branch:- IT, Std. :- TE, Div. :- A,
	Roll no. :- 35026,
	Sub. :-  SP,

	Assignment 2 :- 
		Write a program to implement Pass-II of Two-pass assembler for output of Assignment 1 (The subject
		teacher should provide input file for this assignment).
*/

#include<stdio.h>
#include<string.h>

struct symtable
{
	int sym_cnt,addr;
	char sym_name[10];
}st[10];

struct littable
{
	int lit_cnt,addr;
	char lit_name[10];
}lt[10];

int ist=0,ilt=0,ipt=0;

void dispst(struct symtable *st)
{
	printf("\n\t%d\t %s\t   %d",st->sym_cnt,st->sym_name,st->addr);
}

void displt(struct littable *lt)
{
	printf("\n\t%d\t %s\t   %d",lt->lit_cnt,lt->lit_name,lt->addr);
}

void add_st()
{
	int n,i;
	printf("\n\tEnter the no. of Symbols :");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		st[ist].sym_cnt=ist+1;
		printf("\n\tEnter the name & address of Symbol %d : ",i+1);
		scanf("%s%d",st[ist].sym_name,&st[ist].addr);
		ist++;
	}
}

void add_lt()
{
	int n,i;
	printf("\n\tEnter the no. of Literals :");
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		lt[ilt].lit_cnt=ilt+1;
		printf("\n\tEnter the name & address of Literal %d : ",i+1);
		scanf("%s%d",lt[ilt].lit_name,&lt[ilt].addr);
		ilt++;
	}
}

char * trim(char t[10])
{
	t[strlen(t)-1]='\0';
	return t;
}

int main()
{
	FILE *fp,*fp1;
	
	int i,n,addr;
	char buffer[180],t1[10],t2[10],t3[10],t4[10],t5[10],t6[10];
	
	printf("\n\t\t**Two Pass assembler (Pass #2)**\n");
	
	add_st();
	add_lt();
	
	printf("\n\n\tSymbol Table: \n\t");
	printf("\n\tSym_Cnt  Sym_Name  Addr");	
	for(i=0;i<ist;i++)
		dispst(&st[i]);
		
	printf("\n\tLiteral Table: \n\t");
	printf("\n\tLit_Cnt  Lit_Name  Addr");	
	for(i=0;i<ilt;i++)
		displt(&lt[i]);
		
	printf("\n");	
	
	fp=fopen("ic.txt","r");
	fp1=fopen("tc.txt","w");
	
	while(fgets(buffer,180,fp))
	{
		n=sscanf(buffer,"%s%s%s%s%s%s",t1,t2,t3,t4,t5,t6);
		switch(n)
		{
			case 4:
				if(t1[0]=='(')
					fprintf(fp1,"\n\t\t%s %s %s",trim(t2),t3,t4);
				else
					fprintf(fp1,"\n\t\t%s %s %s %s",t1,t2,t3,t4);
			break;
			
			case 5:
				if(t1[0]=='(')
					fprintf(fp1,"\n\t\t\t %s %s %s",trim(t2),t3,trim(t5));
				else	
					fprintf(fp1,"\n\t\t%s %s %s %s",t1,trim(t3),t4,t5);			
			break;
			
			case 6:
				if(t5[1]=='S')
					addr=st[atoi(trim(t6))-1].addr;
				else if(t5[1]=='L')
					addr=lt[atoi(trim(t6))-1].addr;
				fprintf(fp1,"\n\t\t%s %s %s %d",t1,trim(t3),t4,addr);
			break;
		}
	}
}


